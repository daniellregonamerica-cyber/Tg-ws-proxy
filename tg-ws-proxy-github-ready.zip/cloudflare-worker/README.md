# Cloudflare Worker для TG WS Proxy

Этот каталог содержит Cloudflare Worker из основного `tg-ws-proxy` проекта, перенесённый в Android-репозиторий.

Worker принимает WebSocket на `/apiws?dst=<telegram-ip>` и проксирует данные между WebSocket и TCP-соединением к `dst:443`.

## Деплой

Установите Wrangler и выполните из этого каталога:

```bash
npx wrangler login
npx wrangler deploy
```

После деплоя Cloudflare выдаст домен вида:

```text
<имя>.<аккаунт>.workers.dev
```

Этот домен используется приложением как адрес Cloudflare Worker.

## Проверка

Обычные HTTP-запросы Worker намеренно отклоняет с кодом `426`, а пути кроме `/apiws` возвращают `404`.

Для работы нужен именно WebSocket-запрос к:

```text
wss://<worker-domain>/apiws?dst=<telegram-ip>
```

Код Worker перенесён без изменения сетевой логики из `docs/RU/CfWorker.md` исходного проекта.
